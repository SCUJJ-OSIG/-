/**
 * 目标：把地图和人物渲染到画布上
 */

// 1、获取到画布的上下文对象
const cvs = document.querySelector('.canvas')
const cxt = cvs.getContext('2d')

const sizes = {
  width:window.innerWidth,
  height:window.innerHeight
}

const offset = {
  x:-610,
  y:-480
}

cvs.width = sizes.width
cvs.height = sizes.height

// 从原始的一维数组转成二位数组，  slice  每隔100项截取一次， 返回一个新的数组 100   start,  length
const collisionsMap = []
for(let i=0;i<collisions.length;i+=100){
  collisionsMap.push(collisions.slice(i,100+i))
}

const transferMap = []
for(let i=0;i<transfers.length;i+=100){
  transferMap.push(transfers.slice(i,100+i))
}

class Boundary {
  constructor({position,type}){
    this.position = position
    this.width = 64
    this.height = 64
    this.type = type
  }
  draw(){
    if(this.type === 'transferA'){
      cxt.fillStyle = 'red'
    }else if(this.type === 'transferB'){
      cxt.fillStyle = 'white'
    }else{
      cxt.fillStyle = 'green'
    }
    
    cxt.fillRect(this.position.x,this.position.y,this.width,this.height)
  }
}
const boundaries = []
collisionsMap.forEach((row,i) => {
  row.forEach((symbol,j) => {
    if(symbol === 431){
      boundaries.push(
        new Boundary({
          position:{
            x: 64 * j  + offset.x,
            y: 64 * i + offset.y
          }
        })
      )
    }
  })
})
const transferZones = []
transferMap.forEach((row,i) => {
  row.forEach((symbol,j) => {
    if(symbol === 431 || symbol === 436){
      const type = symbol === 431 ? 'transferA' : 'transferB'
      transferZones.push(
        new Boundary({
          position:{
            x: 64 * j  + offset.x,
            y: 64 * i + offset.y
          },
          type
        })
      )
    }
  })
})

// 2、把地图渲染到画布上
const mapImage = new Image()
mapImage.src = './images/map.png'
// 3、引入人物图像
const playerDownImgage = new Image()
playerDownImgage.src = './images/playerDown.png'
const playerUpImgage = new Image()
playerUpImgage.src = './images/playerUp.png'
const playerLeftImgage = new Image()
playerLeftImgage.src = './images/playerLeft.png'
const playerRightImgage = new Image()
playerRightImgage.src = './images/playerRight.png'
const foregroundImage = new Image()
foregroundImage.src = './images/foreground.png'
class Sprite {
  constructor({image,position,frames={max:1},sprites}){
    this.image = image 
    this.position = position
    this.frames = {...frames,num:0,speed:0}
    this.sprites = sprites
    this.image.onload = () => {
      this.width = this.image.width / this.frames.max
      this.height = this.image.height
    }
    this.isMoving = false
  }

  draw(){
    cxt.drawImage(
      this.image,
      this.width * this.frames.num,
      0,
      this.image.width / this.frames.max,
      this.image.height,
      this.position.x,
      this.position.y,
      this.image.width / this.frames.max,
      this.image.height
    )

    if(!this.isMoving) return

    if(this.frames.max > 1){
      this.frames.speed++
    }

    if(this.frames.speed % 10 === 0){
      if(this.frames.num < this.frames.max - 1) this.frames.num++
      else this.frames.num = 0
    }
  }
}

const background = new Sprite({
  image:mapImage,
  position:{
    x:offset.x,
    y:offset.y
  }
})

const foreground = new Sprite({
  image:foregroundImage,
  position:{
    x:offset.x,
    y:offset.y
  }
})

const player = new Sprite({
  image:playerDownImgage,
  position:{
    x:sizes.width/2 - (playerDownImgage.width/4) / 2,
    y:sizes.height/2 - playerDownImgage.height / 2
  },
  frames:{
    max:4
  },
  sprites:{
    down:playerDownImgage,
    up:playerUpImgage,
    left:playerLeftImgage,
    right:playerRightImgage
  }
})



function isCollision({rectangle1,rectangle2}){
  return (
    rectangle1.position.y+rectangle1.height >= rectangle2.position.y && 
    rectangle1.position.y <= rectangle2.position.y + rectangle2.height && 
    rectangle1.position.x+rectangle1.width >= rectangle2.position.x && 
    rectangle1.position.x <= rectangle2.position.x+rectangle2.width
  )
}

// 标识键盘按下
const keys = {
  w:{
    pressed:false
  },
  a:{
    pressed:false
  },
  s:{
    pressed:false
  },
  d:{
    pressed:false
  }
}
// const testBoundary = new Boundary({
//   position:{
//     x:600,
//     y:600
//   }
// })
const movable = [background,...boundaries,foreground,...transferZones]
function animate(){
  window.requestAnimationFrame(animate)
  background.draw()
  // transferZones.forEach(transfer => {
  //   transfer.draw()
  // })
  // boundaries.forEach(boundary => {
  //   boundary.draw()
  // })
  player.draw()
  foreground.draw()
  player.isMoving = false
  let moving = true

  
  if(keys.w.pressed || keys.a.pressed || keys.s.pressed || keys.d.pressed){
    console.log(background.position)
    for(let i=0;i<transferZones.length;i++){
      const transfer = transferZones[i]
      const overArea = (Math.min(
        player.position.x+player.width,
        transfer.position.x+transfer.width
      ) - Math.max(
        player.position.x,
        transfer.position.x
      )) * (Math.min(
        player.position.y+player.height,
        transfer.position.y+transfer.height
      ) - Math.max(
        player.position.y,
        transfer.position.y
      ))
      if(
        isCollision({rectangle1:player,rectangle2:transfer})&&
        overArea > (player.width*player.height)/2
      ){
        console.log('重合了')
        gsap.to('#shade',{
          opacity:1,
          repeat:2,
          duration:0.5,
          onComplete(){
            gsap.to('#shade',{
              opacity:0,
              duration:0.4,
              onComplete(){
                let difX = 0,difY=0;
                if(transfer.type === 'transferA'){
                  difX = -835 - background.position.x     // x轴改变的距离
                  difY = -2037 - background.position.y     // y轴改变的距离
                  
                }
                if(transfer.type === 'transferB'){
                  difX = -3070 - background.position.x     // x轴改变的距离
                  difY = -1092 - background.position.y     // y轴改变的距离
                }

                movable.forEach(rect => {
                  rect.position.x += difX
                  rect.position.y += difY
                })
              }
            })
          }
        })
      }
    }
    
  }
  

  if(keys.w.pressed) {
    player.image = player.sprites.up
    player.isMoving = true

    for(let i=0;i<boundaries.length;i++){
      const boundary = boundaries[i]
      if(isCollision({
        rectangle1:player,
        rectangle2:{...boundary,position:{
          x:boundary.position.x,
          y:boundary.position.y+3
        }}
      })){
        moving = false
        break;
      }
    }
    if(moving){
      movable.forEach(rect => {
        rect.position.y+=3
      })
    }
  }
  if(keys.a.pressed) {
    player.image = player.sprites.left
    player.isMoving = true
    for(let i=0;i<boundaries.length;i++){
      const boundary = boundaries[i]
      if(isCollision({
        rectangle1:player,
        rectangle2:{...boundary,position:{
          x:boundary.position.x+3,
          y:boundary.position.y
        }}
      })){
        moving = false
        break;
      }
    }
    if(moving){
      movable.forEach(rect => {
        rect.position.x+=3
      })
    }
  }
  if(keys.s.pressed) {
    player.image = player.sprites.down
    player.isMoving = true
    for(let i=0;i<boundaries.length;i++){
      const boundary = boundaries[i]
      if(isCollision({
        rectangle1:player,
        rectangle2:{...boundary,position:{
          x:boundary.position.x,
          y:boundary.position.y-3
        }}
      })){
        moving = false
        break;
      }
    }
    if(moving){
      movable.forEach(rect => {
        rect.position.y-=3
      })
    }
  }
  if(keys.d.pressed) {
    player.image = player.sprites.right
    player.isMoving = true
    for(let i=0;i<boundaries.length;i++){
      const boundary = boundaries[i]
      if(isCollision({
        rectangle1:player,
        rectangle2:{...boundary,position:{
          x:boundary.position.x-3,
          y:boundary.position.y
        }}
      })){
        moving = false
        break;
      }
    }
    if(moving){
      movable.forEach(rect => {
        rect.position.x-=3
      })
    }
  }
}
animate()
// 5、绑定键盘事件
window.addEventListener('keydown',(event) => {
  switch(event.key){
    case 'w':
      keys.w.pressed = true
      break;
    case 'a':
      keys.a.pressed = true
      break;
    case 's':
      keys.s.pressed = true
      break;
    case 'd':
      keys.d.pressed = true
      break;
  }
})

window.addEventListener('keyup',(event) => {
  switch(event.key){
    case 'w':
      keys.w.pressed = false
      break;
    case 'a':
      keys.a.pressed = false
      break;
    case 's':
      keys.s.pressed = false
      break;
    case 'd':
      keys.d.pressed = false
      break;
  }
})

