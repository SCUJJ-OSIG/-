const sizes = {
  width:1024,
  height:576
}
const gravity = 0.2
export class Spirte {
  constructor({
    cxt,
    image,
    position,
    framesMax = 1,
    scale = 1,
    offset = {x:0,y:0},
    
  }){
    this.cxt = cxt
    this.image = image
    this.position = position
    this.framesMax = framesMax
    this.scale = scale
    this.offset = offset
    this.currentFrame = 0
    this.speed = 0
  }

  draw(){
    this.cxt.drawImage(
      this.image,
      this.image.width / this.framesMax * this.currentFrame,
      0,
      this.image.width / this.framesMax,
      this.image.height,
      this.position.x - this.offset.x,
      this.position.y - this.offset.y,
      this.image.width / this.framesMax * this.scale,
      this.image.height * this.scale
    )
  }
  animateFrame(){
    this.speed++
    if(this.speed % 10 == 0){
      if(this.currentFrame < this.framesMax - 1){
        this.currentFrame++
      }else{
        this.currentFrame = 0
      }
    }
  }
  update(){
    this.draw()
    this.animateFrame()
  }
}

export class Fighter extends Spirte {
  constructor({
    cxt,
    image,
    position,
    velocity = {x:0,y:0},
    framesMax = 1,
    scale = 1,
    offset = {x:0,y:0},
    sprites,
    attackBox = {color:'red',offset:{x:0,y:0}}
  }){
    super({
      cxt, image, position, offset, scale, framesMax
    })
    this.velocity = velocity
    this.sprites = sprites
    this.width = 50
    this.height = this.image.height
    this.attackBox = {
      position:{
        x:this.position.x,
        y:this.position.y
      },
      offset:{
        x:attackBox.offset.x,
        y:attackBox.offset.y
      },
      width:100,
      height:30,
      color:attackBox.color
    }
    this.isAttacking = false
    this.blood = 100
    this.dead = false
  }
  update(){
    this.draw()

    if(!this.dead) this.animateFrame()

    this.attackBox.position.x = this.position.x + this.attackBox.offset.x
    this.attackBox.position.y = this.position.y + this.attackBox.offset.y

    this.position.y = this.position.y + this.velocity.y
    this.position.x = this.position.x + this.velocity.x

    if(this.velocity.y === 0) return

    if(this.position.y + this.image.height + this.velocity.y >= sizes.height){
      this.velocity.y = 0
    }else{
      this.velocity.y += gravity
    }
  }
  switchFrame(sprite){
    if(this.image === this.sprites.death.image){
      if(this.currentFrame === this.sprites.death.framesMax - 1){
        this.dead = true
      }
      return
    }


    if(this.image === this.sprites.attack.image && 
      this.currentFrame < this.framesMax-1
    ) return
    if(this.image === this.sprites.hit.image && 
      this.currentFrame < this.framesMax-1) return


    switch(sprite){
      case 'idle':
        if(this.image !== this.sprites.idle.image){
          this.image = this.sprites.idle.image
          this.framesMax = this.sprites.idle.framesMax
          this.currentFrame = 0
        }
        break
      case 'run':
        if(this.image !== this.sprites.run.image){
          this.image = this.sprites.run.image
          this.framesMax = this.sprites.run.framesMax
          this.currentFrame = 0
        }
        break
      case 'jump':
        if(this.image !== this.sprites.jump.image){
          this.image = this.sprites.jump.image
          this.framesMax = this.sprites.jump.framesMax
          this.currentFrame = 0
        }
        break
      case 'fall':
        if(this.image !== this.sprites.fall.image){
          this.image = this.sprites.fall.image
          this.framesMax = this.sprites.fall.framesMax
          this.currentFrame = 0
        }
        break
      case 'attack':
        if(this.image !== this.sprites.attack.image){
          this.image = this.sprites.attack.image
          this.framesMax = this.sprites.attack.framesMax
          this.currentFrame = 0
        }
        break
      case 'hit':
        if(this.image !== this.sprites.hit.image){
          this.image = this.sprites.hit.image
          this.framesMax = this.sprites.hit.framesMax
          this.currentFrame = 0
        }
        break
      case 'death':
        if(this.image !== this.sprites.death.image){
          this.image = this.sprites.death.image
          this.framesMax = this.sprites.death.framesMax
          this.currentFrame = 0
        }
        break
    }
  }
}