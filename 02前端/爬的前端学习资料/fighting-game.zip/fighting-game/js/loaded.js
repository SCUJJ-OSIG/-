const imgData = {
  background:'../imgs/background.png',
  shop:'../imgs/shop.png',
  player1_idle:'../imgs/player1/Idle.png',
  player1_run:'../imgs/player1/Run.png',
  player1_jump:'../imgs/player1/Jump.png',
  player1_fall:'../imgs/player1/Fall.png',
  player1_attack:'../imgs/player1/Attack1.png',
  player1_hit:'../imgs/player1/Hit.png',
  player1_death:'../imgs/player1/Death.png',
  player2_idle:'../imgs/player2/Idle.png',
  player2_run:'../imgs/player2/Run.png',
  player2_jump:'../imgs/player2/Jump.png',
  player2_fall:'../imgs/player2/Fall.png',
  player2_attack:'../imgs/player2/Attack1.png',
  player2_hit:'../imgs/player2/Hit.png',
  player2_death:'../imgs/player2/Death.png'
}
let num = 0
const obj = {}
export const initLoaded = (callback) => {
  const imgs = Object.keys(imgData)
  imgs.forEach(img => {
    const image = new Image()
    image.src = imgData[img]

    image.onload = () => {
      num++
      obj[img] = image
      if(num === imgs.length){
        callback(obj)
      }
    }
  })
}