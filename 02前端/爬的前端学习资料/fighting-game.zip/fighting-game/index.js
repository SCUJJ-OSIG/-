/**
 * 渲染场景和角色
 */
import { initLoaded } from './js/loaded.js'
import { Spirte, Fighter } from './js/classes.js'

const canvas = document.querySelector('.canvas')
const cxt = canvas.getContext('2d')
const sizes = {
  width:1024,
  height:576
}
canvas.width = sizes.width
canvas.height = sizes.height

const isCollision = ({ rectangle1, rectangle2 }) => {
  return (
    rectangle1.attackBox.position.x + rectangle1.attackBox.width >= rectangle2.position.x &&
    rectangle1.attackBox.position.x <= rectangle2.position.x + rectangle2.width && 
    rectangle1.attackBox.position.y + rectangle1.attackBox.height >= rectangle2.height &&
    rectangle1.position.y <= rectangle2.position.y + rectangle2.height
  )
}

const player1Dom = document.querySelector('#player1')
const player2Dom = document.querySelector('#player2')
const timeDom = document.querySelector('#time')
const tipsDom = document.querySelector('#tips')


initLoaded((Robj) => {
  console.log(Robj)
  const background = new Spirte({
    cxt,
    image:Robj.background,
    position:{x:0,y:0}
  })

  const shop = new Spirte({
    cxt,
    image:Robj.shop,
    position:{ x:600, y:225 },
    framesMax:6,
    scale:2
  })

  const player1 = new Fighter({
    cxt,
    image:Robj.player1_idle,
    position:{ x:350, y:0 },
    framesMax:8,
    scale:2,
    offset:{ x:150, y:140 },
    velocity:{ x:0, y:5 },
    sprites:{
      idle:{ image:Robj.player1_idle, framesMax:8 },
      run:{ image:Robj.player1_run, framesMax:8 },
      jump:{ image:Robj.player1_jump, framesMax:2 },
      fall:{ image:Robj.player1_fall, framesMax:2 },
      attack:{ image:Robj.player1_attack, framesMax:6 },
      hit:{ image:Robj.player1_hit, framesMax:4 },
      death:{ image:Robj.player1_death, framesMax:6 }
    },
    attackBox:{
      color:'red',
      offset:{ x:100, y:30 }
    }
  })

  const player2 = new Fighter({
    cxt,
    image:Robj.player2_idle,
    position:{ x:600, y:0 },
    framesMax:4,
    scale:2,
    offset:{ x:170, y:145 },
    velocity:{ x:0, y:5 },
    sprites:{
      idle:{ image:Robj.player2_idle, framesMax:4 },
      run:{ image:Robj.player2_run, framesMax:8 },
      jump:{ image:Robj.player2_jump, framesMax:2 },
      fall:{ image:Robj.player2_fall, framesMax:2 },
      attack:{ image:Robj.player2_attack, framesMax:4 },
      hit:{ image:Robj.player2_hit, framesMax:3 },
      death:{ image:Robj.player2_death, framesMax:7 }
    },
    attackBox:{
      color:'transparent',
      offset:{ x:-150, y:30 }
    }
  })

  const keys = {
    KeyD:{ pressed:false, lock:false },
    KeyA:{ pressed:false, lock:false },
    KeyW:{ pressed:false, lock:false },
    ArrowLeft:{ pressed:false, lock:false },
    ArrowRight:{ pressed:false, lock:false },
    ArrowUp:{ pressed:false, lock:false }
  }

  window.addEventListener('keydown',(event) => {
    if(keys[event.code] && !keys[event.code].lock){
      keys[event.code].pressed = true
    }
    // 控制角色1和角色2起跳  
    // velocity.y 初始重置为负数
    if(event.code === 'KeyW' && !player1.dead){
      player1.velocity.y = -10
    }
    if(event.code === 'ArrowUp' && !player2.dead){
      player2.velocity.y = -10
    }
    // 控制角色攻击
    if(event.code === 'KeyJ'){
      player1.switchFrame('attack')
      player1.isAttacking = true
    }

    if(event.code === 'Digit0'){
      player2.switchFrame('attack')
      player2.isAttacking = true
    }
  })
  window.addEventListener('keyup',(event) => {
    if(keys[event.code]){
      keys[event.code].pressed = false
    }
  })
  let timer = 60
  let timerId
  function coutDown(){
    if(timer > 0){
      timerId = setTimeout(coutDown,1000)
      timer--
      timeDom.innerHTML = timer
    }
    if(timer === 0){
      clearTimeout(timerId)
      if(player1.blood > player2.blood){
        console.log('player1 winner')
        tipsDom.innerHTML = 'player1 winner'
      }else if(player1.blood < player2.blood){
        console.log('player2 winner')
        tipsDom.innerHTML = 'player2 winner'
      }else{
        console.log('平局')
        tipsDom.innerHTML = '平局'
      }
      tipsDom.style.display = 'block'
    }
  }
  coutDown()
  function animate(){
    window.requestAnimationFrame(animate)
    background.update()
    shop.update()
    player1.update()
    player2.update()

    player1.velocity.x = 0
    player2.velocity.x = 0
    
    
    // 监控 角色1的动作
    if(keys.KeyD.pressed) {
      player1.switchFrame('run')
      player1.velocity.x = 5
    }else if(keys.KeyA.pressed) {
      player1.switchFrame('run')
      player1.velocity.x = -5
    }else{
      player1.switchFrame('idle')
    }
    if(player1.velocity.y < 0){
      player1.switchFrame('jump')
    }else if(player1.velocity.y > 0){
      player1.switchFrame('fall')
    }

    // 监控角色2的动作
    if(keys.ArrowLeft.pressed) {
      player2.switchFrame('run')
      player2.velocity.x = -5
    }else if(keys.ArrowRight.pressed) {
      player2.switchFrame('run')
      player2.velocity.x = 5
    }else{
      player2.switchFrame('idle')
    }

    if(player2.velocity.y<0){
      player2.switchFrame('jump')
    }else if(player2.velocity.y > 0){
      player2.switchFrame('fall')
    }
    // 角色1剑身 a  和 角色2身体b  碰撞
    // a的右侧 大于等于 b的左侧
    // 角色1剑身右侧  player1.attackBox.position.x + player1.attackBox.width
    // 角色1剑身左侧  player1.attackBox.position.x
    // 角色2身体左侧  player2.position.x
    // 角色2身体右侧  player2.position.x + player2.width

    if(isCollision({
      rectangle1:player1,
      rectangle2:player2
    }) && player1.isAttacking && player1.currentFrame === 4){
      console.log('角色1 攻击到了  角色2')
      // player2.switchFrame('hit')
      player1.isAttacking = false
      player2.blood -= 20

      if(player2.blood <= 0){
        player2.switchFrame('death')
      }else player2.switchFrame('hit')

      player2Dom.style.width = player2.blood + '%'
    }

    if(isCollision({
      rectangle1:player2,
      rectangle2:player1
    }) && player2.isAttacking && player2.currentFrame === 2){
      console.log('角色2 攻击到了 角色1')
      // player1.switchFrame('hit')
      player2.isAttacking = false
      player1.blood -= 20

      if(player1.blood <= 0){
        player1.switchFrame('death')
      }else player1.switchFrame('hit')

      player1Dom.style.width = player1.blood + '%'
    }

    if(player1.isAttacking && player1.currentFrame === 6){
      player1.isAttacking = false
    }

    if(player2.isAttacking && player2.currentFrame === 3){
      player2.isAttacking = false
    }

    if(player1.blood === 0 || player2.blood === 0){
      clearTimeout(timerId)
      if(player1.blood > player2.blood){
        console.log('player1 winner')
        tipsDom.innerHTML = 'player1 winner'
      }else if(player1.blood < player2.blood){
        console.log('player2 winner')
        tipsDom.innerHTML = 'player2 winner'
      }else{
        console.log('平局')
        tipsDom.innerHTML = '平局'
      }
      tipsDom.style.display = 'block'
    }

    if(player2.dead){
      keys.ArrowLeft.lock = true
      keys.ArrowRight.lock = true
    }
    if(player1.dead){
      keys.KeyA.lock = true
      keys.KeyD.lock = true
    }
  }
  animate()
})

