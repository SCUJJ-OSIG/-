import { createRouter, createWebHashHistory } from 'vue-router'

export const constantRoutes = [
  {
    path:'/',
    redirect:'/login'
  },
  {
    path:'/login',
    name:'Login',
    component:()=>import('@/pages/login')
  },
  {
    path:'/dashboard', 
    name:'Dashboard',
    component:()=>import('@/pages/dashboard')
  }
]

export const asyncRoutes = [
  {
    path:'/userManage',
    name:'UserManage',
    redirect:'/userManage/list',
    component:()=>import('@/pages/dashboard'),
    meta:{ name:'账户管理' },
    children:[
      {
        path:'list',
        name:'UserList',
        component:()=>import('@/pages/user/index'),
        meta:{ name:'账户管理' },
      }
    ]
  },
  {
    path:'/roleManage',
    redirect:'/roleManage/list',
    name:'RoleManage',
    component:()=>import('@/pages/dashboard'),
    meta:{ name:'角色管理' },
    children:[
      {
        path:'list',
        name:'RoleList',
        component:()=>import('@/pages/user/role'),
        meta:{ name:'角色列表' }
      },    
    ]
  },
  {
    path:'/menuManage',
    redirect:'/menuManage/list',
    name:'MenuManage',
    component:()=>import('@/pages/dashboard'),
    meta:{ name:'菜单管理' },
    children:[
      {
        path:'list',
        name:'MenuList',
        component:()=>import('@/pages/user/menu'),
        meta:{ name:'菜单列表' }
      },
      {
        path:'add',
        name:'MenuAdd',
        component:()=>import('@/pages/user/addMenu'),
        meta:{ name:'添加菜单' }
      }
    ]
  },
  {
    path:'/orderManage',
    redirect:'/orderManage/list',
    name:'OrderManage',
    component:()=>import('@/pages/dashboard'),
    meta:{ name:'订单管理' },
    children:[
      {
        path:'list',
        name:'OrderList',
        component:()=>import('@/pages/order/list'),
        meta:{ name:'订单列表' }
      },
      {
        path:'detail',
        name:'OrderDetail',
        component:()=>import('@/pages/order/detail'),
        meta:{ name:'订单详情' }
      }
    ]
  },
  {
    path:'/productManage',
    redirect:'/productManage/list',
    name:'ProductManage',
    component:()=>import('@/pages/dashboard'),
    meta:{ name:'产品管理' },
    children:[
      {
        path:'list',
        name:'ProductList',
        component:()=>import('@/pages/product/list'),
        meta:{ name:'产品列表' }
      },
      {
        path:'detail',
        name:'ProductDetail',
        component:()=>import('@/pages/product/detail'),
        meta:{ name:'产品详情' }
      }
    ]
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes:constantRoutes
})

export default router
