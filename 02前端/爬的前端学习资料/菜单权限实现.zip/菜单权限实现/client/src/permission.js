import router from './router'
import { menuApi } from '@/apis'
import {asyncRoutes} from './router'

router.beforeEach(async (to,from, next)=>{
  if(to.path === '/login'){
    await next()
  }else{
    const menusResult = await menuApi()
    const menus = menusResult.data.menus
    const addRoutes = []
    asyncRoutes.forEach((item) => {
      if(menus.find(menu => menu.link_url === item.path)){
        const children = []
        if(item.children && item.children.length){
          item.children.forEach(child => {
            if(menus.find(menu => menu.component === child.name)){
              children.push(child)
            }
          })
        }
        addRoutes.push({
          path:item.path,
          redirect:item.redirect,
          component:item.component,
          children,
          meta:item.meta
        })
      }
    })
    addRoutes.forEach(route => {
      router.addRoute(route)
    })

    sessionStorage.setItem('accessRoutes',JSON.stringify(addRoutes))
    await next()
  }
  
  
})