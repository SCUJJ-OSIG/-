<template>
  <div class="content-wrapper">
    <div class="top">
      添加菜单


     <el-form :model="form">
        <el-form-item label="菜单名" :label-width="100">
          <el-input v-model="form.name" autocomplete="off" />
        </el-form-item>
        <el-form-item label="父节点id" :label-width="100">
          <el-input v-model="form.parent_id" autocomplete="off" />
        </el-form-item>
        <el-form-item label="路由" :label-width="100">
          <el-input v-model="form.link_url" autocomplete="off" />
        </el-form-item>
        <el-form-item label="组件名" :label-width="100">
          <el-input v-model="form.component" autocomplete="off" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">添加</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
  import { defineComponent,reactive,toRefs } from 'vue'
  import { useRouter } from 'vue-router'
  import { menuCreateApi } from '@/apis'
  export default defineComponent({
    setup(){
      const uRouter = useRouter()
      const state = reactive({
        form:{}
      })
      const onSubmit = () => {
        menuCreateApi(state.form).then(res => {
          if(res.code === 200){
            uRouter.push({path:'/menuManage/list'})
          }
        })
      }
      return {
        ...toRefs(state),
        onSubmit
      }
    }
  })
</script>
<style lang="scss">
.content-wrapper{
  padding:20px;
  .top{
    margin-bottom:20px;
  }
}
</style>