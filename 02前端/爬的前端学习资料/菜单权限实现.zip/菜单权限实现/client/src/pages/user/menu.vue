<template>
  <div class="content-wrapper">
    <div class="top">
      账户管理
    </div>
    <el-tree :data="data" :default-expand-all="true">

      <template #default="{ data }">
        <span class="custom-tree-node">
          <span>{{ data.name }}({{data.id}}) ----- {{data.link_url}}</span>
        </span>
      </template>
    </el-tree>
  </div>
</template>
<script>
  import { defineComponent,reactive,toRefs } from 'vue'
  import { menuListApi } from '@/apis'
  export default defineComponent({
    setup(){
      const state = reactive({
        defaultProps:{
          children: 'children',
          label: 'name',
        },
        data :[]
      })
      const getMenuListApi = ()=> {
        menuListApi().then(res => {
          console.log(res)
          if(res.code === 200){
            state.data = res.data
          }
        })
      }
      getMenuListApi()
      return {
        ...toRefs(state)
      }
    }
  })
</script>
<style lang="scss">
.content-wrapper{
  padding:20px;
  .top{
    margin-bottom:20px;
  }
}
</style>