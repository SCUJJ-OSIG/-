<template>
  <div class="content-wrapper">
    <div class="top">
      账户管理
      <el-button @click="dialogVisible=true">添加账户</el-button>
    </div>

    <el-table
      :data="tableData"
      style="width: 100%"
    >
      <el-table-column prop="id" label="Id" width="180" />
      <el-table-column prop="name" label="昵称" width="180" />
      <el-table-column prop="phone" label="账号" />
      <el-table-column label="角色">
        <template #default="scope">
          <div>
            <p v-if="scope.row.r_id === 0">/</p>
            <p v-else>{{scope.row.role.name}}</p>
          </div>
        </template>
      </el-table-column>
      <el-table-column label="状态">
        <template #default="scope">
          <div>
            <p>{{scope.row.status ? '正常' : '冻结'}}</p>
          </div>
        </template>
      </el-table-column> 
      <el-table-column fixed="right" label="Operations" width="120">
        <template #default="scope">
          <el-button link type="primary" size="small" @click="handleClick(scope.row.id)"
            >编辑角色</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination layout="prev, pager, next" :page-size="query.pageSize" :total="total" @current-change="handleChange" />
    </div>

    <el-dialog 
      v-model="dialogVisible" 
      title="添加账户"
      width="30%"
    >
      <el-form :model="form">
        <el-form-item label="账户名称" :label-width="100">
          <el-input v-model="form.name" autocomplete="off" />
        </el-form-item>
        <el-form-item label="账户号" :label-width="100">
          <el-input v-model="form.phone" autocomplete="off" />
        </el-form-item>
        <el-form-item label="密码" :label-width="100">
          <el-input v-model="form.password" autocomplete="off" />
        </el-form-item>
        <el-form-item label="角色" :label-width="100">
          <el-select v-model="form.r_id">
            <el-option
              v-for="item in rOption"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submit"
            >Confirm</el-button
          >
        </span>
      </template>
    </el-dialog>

    <el-dialog 
      v-model="roleVisible" 
      title="添加账户"
      width="30%"
    >
      <el-form :model="updateForm">
        <el-form-item label="角色" :label-width="100">
          <el-select v-model="updateForm.r_id">
            <el-option
              v-for="item in rOption"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="roleVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitUpdate"
            >Confirm</el-button
          >
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script>
import { defineComponent, ref, toRefs, reactive } from 'vue'
import {accountList,roleListApi,userCreateApi,userUpdateApi} from '@/apis'
export default defineComponent({
  setup(){
    const tableData = ref([])
    const total = ref(0)

    const state = reactive({
      query:{
        pageNum:1,
        pageSize:10
      },
      form:{},
      updateForm:{},
      dialogVisible:false,
      rOption:[],
      user_id:0,
      roleVisible:false
    })

    const getAccountList = ()=> {
      accountList(state.query).then(res => {
        if(res.code === 200){
          tableData.value = res.data.rows
          total.value = Number(res.data.count)
        }
      })
    }
    getAccountList()

    const getRolList = () => {
      roleListApi().then(res => {
        if(res.code === 200){
          state.rOption = res.data
        }
      })
    }
    getRolList()

    const handleChange = (v) => {
      state.query.pageNum = v
      getAccountList()
    }

    const submit = () => {
      userCreateApi(state.form).then(res => {
        if(res.code === 200){
          state.dialogVisible = false
          getAccountList()
        }
      })
    }

    const handleClick = (v) => {
      state.user_id = v 
      state.roleVisible = true
    }

    const submitUpdate = () => {
      userUpdateApi({
        r_id:state.updateForm.r_id,
        id:state.user_id
      }).then(res => {
        if(res.code === 200){
          getAccountList()
          state.roleVisible = false
        }
      })
    }
    
    return {
      tableData,
      total,
      ...toRefs(state),
      handleChange,
      submit,
      handleClick,
      submitUpdate
    }
  }
})
</script>

<style lang="scss">
.content-wrapper{
  padding:20px;
  .top{
    margin-bottom:20px;
  }
}
.pagination{
  text-align:center;
}
</style>