<template>
  <div class="content-wrapper">
    <div class="top">
      角色管理
      <el-button @click="dialogVisible = true">添加角色</el-button>
    </div>

    <el-table
      :data="tableData"
      style="width: 100%"
    >
      <el-table-column prop="id" label="Id" width="180" />
      <el-table-column prop="name" label="昵称" width="180" />
      <el-table-column label="状态">
        <template #default="scope">
          <div>
            <p>{{scope.row.status ? '有效' : '冻结'}}</p>
          </div>
        </template>
      </el-table-column> 
      <el-table-column fixed="right" label="Operations" width="120">
        <template #default="scope">
          <el-button link type="primary" size="small" @click="handleClick(scope.row.id)"
            >授权</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog 
      v-model="menuVisible" 
      title="菜单授权"
      width="30%"
    >
      <el-tree 
      ref="treeRef"
      :data="data"
      show-checkbox
      default-expand-all
      node-key="id">

        <template #default="{ data }">
          <span class="custom-tree-node">
            <span>{{ data.name }}({{data.id}}) ----- {{data.link_url}}</span>
          </span>
        </template>
      </el-tree>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="menuVisible = false">Cancel</el-button>
          <el-button type="primary" @click="getChecked"
            >Confirm</el-button
          >
        </span>
      </template>
    </el-dialog>
    <el-dialog 
      v-model="dialogVisible" 
      title="添加角色"
      width="30%"
    >
      <el-form :model="form">
        <el-form-item label="角色名称" :label-width="100">
          <el-input v-model="form.name" autocomplete="off" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submit"
            >Confirm</el-button
          >
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script>
import { defineComponent, reactive, toRefs, ref } from 'vue'
import {roleListApi,roleCreateApi,menuListApi,addRoleMenuApi,roleMenuListApi} from '@/apis'
export default defineComponent({
  setup(){
    const state = reactive({
      dialogVisible:false,
      tableData:[],
      form:{},
      menuVisible:false,
      role_id:0,
      data :[]
    })

    const getRolList = ()=> {
      roleListApi().then(res => {
        if(res.code === 200){
          state.tableData = res.data
        }
      })
    }
    getRolList()

    const submit = ()=> {
      roleCreateApi(state.form).then(res => {
        if(res.code === 200){
          state.dialogVisible = false
          getRolList()
        }
      })
    }

    const getMenuChecked = () => {
      roleMenuListApi({r_id:state.role_id}).then(res => {
        if(res.code === 200){
          const menuCheckeds = res.data.menus.map(item => {
            return Number(item.id)
          })

          treeRef.value.setCheckedKeys(menuCheckeds, false)
        }
      })
    }

    const getMenuListApi = ()=> {
      menuListApi().then(res => {
        if(res.code === 200){
          state.data = res.data
        }
      })
    }
    getMenuListApi()
    const handleClick = (v) => {
      state.menuVisible = true
      state.role_id = v

      getMenuChecked()
    }
    const treeRef = ref()
    const getChecked = ()=> {
      const checks = treeRef.value.getCheckedNodes(false, true)
      const menu_ids = checks.map(item => {
        return item.id
      })


      addRoleMenuApi({
        r_id:state.role_id,
        menu_id:menu_ids.join(',')
      }).then(res => {
        if(res.code === 200){
          state.menuVisible = false
          state.role_id = 0
          treeRef.value.setCheckedKeys([], false)
        }
      })

      // treeRef.value.setCheckedKeys([], false)
    }
    
    return {
      ...toRefs(state),
      submit,
      handleClick,
      getChecked,
      treeRef
    }
  }
})
</script>

<style lang="scss">
.content-wrapper{
  padding:20px;
  .top{
    margin-bottom:20px;
  }
}
</style>