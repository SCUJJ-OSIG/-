<template>
  <div class="login-wrapper">
    <div class="form-box">
      <el-form :model="loginForm" label-width="100px">
        <el-form-item label="账户名">
          <el-input v-model="loginForm.phone"></el-input>
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="loginForm.password"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { defineComponent, reactive, toRefs } from 'vue'
import {useRouter} from 'vue-router'
import { loginApi } from '@/apis'
export default defineComponent({
  name:'Login',
  setup(){
    const state = reactive({
      loginForm:{}
    })

    const uRouter = new useRouter()

    const onSubmit = ()=> {
      loginApi(state.loginForm).then(res => {
        if(res.code === 200){
          sessionStorage.setItem('token',`Bearer ${res.data.token}`)
          sessionStorage.setItem('username',res.data.name)
          uRouter.push({
            name:'Dashboard'
          })
        }
      })
    }

    return {
      ...toRefs(state),
      onSubmit
    }
  }
})
</script>
<style lang="scss">
.login-wrapper{
  width:100%;
  height:100%;
  display:flex;
  justify-content:center;
  align-items:center;

  .form-box{
    padding:30px;
    width:400px;
    border-radius:4px;
    box-shadow:0 0 8px 2px #555555;
  }
}
</style>