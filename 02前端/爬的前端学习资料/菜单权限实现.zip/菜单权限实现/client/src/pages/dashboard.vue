<template>
  <div class="dashboard">
    <div class="header">
      <p class="username">{{username}}</p>
    </div>
    <div class="content">
      <div class="content-container">
        <div class="content-container-sidebar">
          <el-menu
            active-text-color="#ffd04b"
            background-color="#545c64"
            class="el-menu-vertical-demo"
            default-active="2"
            text-color="#fff"
            :router="true"
          >
            <el-sub-menu :index="item.path" v-for="item in routes" :key="item.path">
              <template #title>
                <el-icon><location /></el-icon>
                <span>{{item.meta.name}}</span>
              </template>
              <el-menu-item v-for="route in item.children" :key="route.path" :index="`${item.path}/${route.path}`">
                <el-icon><setting /></el-icon>
                <span>{{route.meta.name}}</span>
              </el-menu-item>
            </el-sub-menu>
           
          </el-menu>
        </div>
        <div class="content-container-box">
          <router-view/>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { computed, defineComponent } from 'vue'
export default defineComponent({
  name:'Dashboard',
  setup(){
    const routes = JSON.parse(sessionStorage.getItem('accessRoutes'))
    const username = sessionStorage.getItem('username')
    return {
      routes,
      username
    }
  }
})
</script>
<style lang="scss">
.dashboard{
  height:100%;
  overflow:hidden;
  position:relative;
  .header{
    width:100%;
    height:50px;
    background:#ce3a3a;
    padding:0 20px;
    .username{
      height:100%;
      color:#fff;
      display:flex;
      align-items:center;
      
    }
  }

  .content{
    position:absolute;
    top:50px;
    bottom:0;
    left:0;
    right:0;
    &-container{
      width:100%;
      height:100%;
      display:flex;

      &-sidebar{
        width:200px;
        flex:0 0 200px;
        height:100%;
        overflow-y:auto;
      }
      &-box{
        margin-left:20px;
        flex:1;
        height:100%;
        background:#ccc;
      }
    }
  }
}
</style>