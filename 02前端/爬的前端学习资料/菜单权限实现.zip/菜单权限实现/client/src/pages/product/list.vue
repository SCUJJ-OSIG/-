<template>
  <div class="content-wrapper">
    <div class="top">
      产品列表
    </div>

  </div>
</template>
<script>
import { defineComponent, ref, toRefs, reactive } from 'vue'
export default defineComponent({
})
</script>

<style lang="scss">
.content-wrapper{
  padding:20px;
  .top{
    margin-bottom:20px;
  }
}
.pagination{
  text-align:center;
}
</style>