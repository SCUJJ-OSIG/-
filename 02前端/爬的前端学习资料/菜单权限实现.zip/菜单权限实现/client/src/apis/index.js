import http from './http';

export const loginApi = data => {
  return http({
      url:'/admin/login',
      method:'post',
      data
  })
}


export const accountList = data => {
  return http({
      url:'/admin/userListByPage',
      method:'get',
      params:data
  })
}

export const userCreateApi = (data={}) => {
  return http({
      url:'/admin/userCreate',
      method:'post',
      data
  })
}

export const roleListApi = (data={}) => {
  return http({
      url:'/admin/roleList',
      method:'get',
      params:data
  })
}

export const roleCreateApi = (data={}) => {
  return http({
      url:'/admin/roleCreate',
      method:'post',
      data
  })
}

export const menuCreateApi = (data={}) => {
  return http({
    url:'/admin/menuCreate',
    method:'post',
    data
  })
}

export const menuListApi = (data={}) => {
  return http({
    url:'/admin/menuList',
    method:'get',
    params:data
  })
}

export const addRoleMenuApi = (data) => {
  return http({
    url:'/admin/addRoleMenu',
    method:'post',
    data
  })
}

export const roleMenuListApi = (data={}) => {
  return http({
    url:'/admin/menuchecked',
    method:'get',
    params:data
  })
}

export const menuApi = (data = {}) => {
  return http({
    url:'/admin/menu',
    method:'get',
    params:data
  })
}

export const userUpdateApi = (data) => {
  return http({
    url:'/admin/userUpdate',
    method:'post',
    data
  })
}

