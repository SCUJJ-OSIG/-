import axios from 'axios'

const http = axios.create({
  baseURL:'http://192.168.3.91:3000',
  timeout:5000
})

http.interceptors.request.use(config => {
  if (sessionStorage.getItem('token')) {
    config.headers['token'] = sessionStorage.getItem('token')
  }

    return config
},error => {
    return Promise.reject(error)
})

http.interceptors.response.use(response => {
    if(response.status != 200){
        return response
    }else{
        return response.data
    }
},error => {
    return Promise.reject(error)
})

export default http;