/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80032
 Source Host           : localhost:3306
 Source Schema         : some

 Target Server Type    : MySQL
 Target Server Version : 80032
 File Encoding         : 65001

 Date: 12/07/2023 14:58:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin_user
-- ----------------------------
DROP TABLE IF EXISTS `admin_user`;
CREATE TABLE `admin_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `status` tinyint NULL DEFAULT 1,
  `r_id` int NULL DEFAULT 0,
  `create_time` datetime NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin_user
-- ----------------------------
INSERT INTO `admin_user` VALUES (1, 'admin', 'd6b0ab7f1c8ab8f514db9a6d85de160a', 'admin', 1, 1, '2023-07-12 11:28:53');
INSERT INTO `admin_user` VALUES (2, '张三', 'd6b0ab7f1c8ab8f514db9a6d85de160a', '子账号1', 1, 2, '2023-07-12 11:50:02');
INSERT INTO `admin_user` VALUES (3, '李四', 'd6b0ab7f1c8ab8f514db9a6d85de160a', '子账号2', 1, 4, '2023-07-12 13:58:19');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `parent_id` mediumint NULL DEFAULT 0,
  `link_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `component` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES (1, '账户管理', 0, '/userManage', 'UserManage', '2023-07-12 11:29:31');
INSERT INTO `menu` VALUES (2, '账户管理', 1, '/userManage/list', 'UserList', '2023-07-12 11:33:08');
INSERT INTO `menu` VALUES (3, '角色管理', 0, '/roleManage', 'RoleManage', '2023-07-12 11:33:54');
INSERT INTO `menu` VALUES (4, '角色列表', 3, '/roleManage/list', 'RoleList', '2023-07-12 11:34:32');
INSERT INTO `menu` VALUES (5, '菜单管理', 0, '/menuManage', 'MenuManage', '2023-07-12 11:37:08');
INSERT INTO `menu` VALUES (6, '菜单列表', 5, '/menuManage/list', 'MenuList', '2023-07-12 11:38:23');
INSERT INTO `menu` VALUES (7, '菜单添加', 5, '/menuManage/add', 'MenuAdd', '2023-07-12 11:48:44');
INSERT INTO `menu` VALUES (8, '订单管理', 0, '/orderManage', 'OrderManage', '2023-07-12 13:51:39');
INSERT INTO `menu` VALUES (9, '订单管理', 8, '/orderManage/list', 'OrderList', '2023-07-12 13:56:19');

-- ----------------------------
-- Table structure for menu_role
-- ----------------------------
DROP TABLE IF EXISTS `menu_role`;
CREATE TABLE `menu_role`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `menu_id` int UNSIGNED NULL DEFAULT NULL,
  `role_id` int UNSIGNED NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `menu_role_role_id_menu_id_unique`(`menu_id`, `role_id`) USING BTREE,
  INDEX `role_id`(`role_id`) USING BTREE,
  CONSTRAINT `menu_role_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `menu_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of menu_role
-- ----------------------------
INSERT INTO `menu_role` VALUES (1, 1, 1, '2023-07-12 11:35:12');
INSERT INTO `menu_role` VALUES (6, 2, 1, '2023-07-12 11:40:23');
INSERT INTO `menu_role` VALUES (7, 3, 1, '2023-07-12 11:45:07');
INSERT INTO `menu_role` VALUES (8, 4, 1, '2023-07-12 11:45:15');
INSERT INTO `menu_role` VALUES (9, 5, 1, '2023-07-12 11:45:22');
INSERT INTO `menu_role` VALUES (10, 6, 1, '2023-07-12 11:47:47');
INSERT INTO `menu_role` VALUES (11, 7, 1, '2023-07-12 11:49:00');
INSERT INTO `menu_role` VALUES (15, 3, 2, '2023-07-12 13:50:36');
INSERT INTO `menu_role` VALUES (16, 4, 2, '2023-07-12 13:50:36');
INSERT INTO `menu_role` VALUES (17, 5, 2, '2023-07-12 13:50:36');
INSERT INTO `menu_role` VALUES (18, 6, 2, '2023-07-12 13:50:36');
INSERT INTO `menu_role` VALUES (19, 7, 2, '2023-07-12 13:50:36');
INSERT INTO `menu_role` VALUES (20, 1, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (21, 2, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (22, 3, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (23, 4, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (24, 5, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (25, 6, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (26, 7, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (27, 8, 4, '2023-07-12 13:57:54');
INSERT INTO `menu_role` VALUES (28, 9, 4, '2023-07-12 13:57:54');

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `status` tinyint NULL DEFAULT 1,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '管理员', 1, '2023-07-12 11:32:02');
INSERT INTO `role` VALUES (2, '主管', 1, '2023-07-12 11:32:06');
INSERT INTO `role` VALUES (3, '普通员工', 1, '2023-07-12 11:32:21');
INSERT INTO `role` VALUES (4, '店长', 1, '2023-07-12 13:56:55');

SET FOREIGN_KEY_CHECKS = 1;
