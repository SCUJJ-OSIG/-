const { DataTypes, Op } = require('sequelize')
const dayjs = require('dayjs')
const md5 = require('md5')
const { ParameterError, NotExist } = require('../utils/errorType')
const sequelize = require('../utils/db')

const AdminUserModel = sequelize.define('admin_user',{
  id:{
    type:DataTypes.INTEGER.UNSIGNED,
    autoIncrement:true,
    primaryKey:true
  },
  phone:{
    type:DataTypes.STRING,
    allowNull:false
  },
  password:{
    type:DataTypes.STRING,
    allowNull:false,
    set(val){
      this.setDataValue('password',md5(val))
    }
  },
  name:{
    type:DataTypes.STRING
  },
  status:{
    type:DataTypes.TINYINT,
    defaultValue:1
  },
  r_id:{
    type:DataTypes.INTEGER,
    defaultValue:0
  },
  create_time:{
    type:DataTypes.DATE,
    defaultValue:DataTypes.NOW,
    get(){
      const val = this.getDataValue('create_time')
      return dayjs(val).format("YYYY-MM-DD HH:mm:ss")
    }
  }
})

AdminUserModel.verifyAccountPassword = async (phone, password) => {
  const user = await AdminUserModel.findOne({
    where:{
      [Op.and]:[
        {phone},
        {status:1}
      ]
    }
  })
  if(!user){
    console.log(56)
    throw new NotExist('用户不存在')
  }
  if(user.password !== md5(password)){
    console.log(89)
    throw new ParameterError('账户密码错误')
  }
  return user
}

module.exports = AdminUserModel