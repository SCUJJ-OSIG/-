const { DataTypes, Op } = require('sequelize')
const dayjs = require('dayjs')
const sequelize = require('../utils/db')

const RoleModel = sequelize.define('role',{
  id:{
    type:DataTypes.INTEGER.UNSIGNED,
    autoIncrement:true,
    primaryKey:true
  },
  name:{
    type:DataTypes.STRING,
    allowNull:false
  },
  status:{
    type:DataTypes.TINYINT,
    defaultValue:1
  },
  create_time:{
    type:DataTypes.DATE,
    defaultValue:DataTypes.NOW,
    get(){
      const val = this.getDataValue('create_time')
      return dayjs(val).format("YYYY-MM-DD HH:mm:ss")
    }
  }
})


module.exports = RoleModel