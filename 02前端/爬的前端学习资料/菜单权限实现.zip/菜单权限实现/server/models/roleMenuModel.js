const { DataTypes } = require('sequelize')
const dayjs = require('dayjs')
const sequelize = require('../utils/db')
const MenuModel = require('./menuModel')
const RoleModel = require('./roleModel')

const MenuRoleModel = sequelize.define('menu_role',{
  id:{
    type:DataTypes.INTEGER.UNSIGNED,
    autoIncrement:true,
    primaryKey:true
  },
  menu_id:{
    type:DataTypes.INTEGER
  },
  role_id:{
    type:DataTypes.INTEGER
  },
  create_time:{
    type:DataTypes.DATE,
    defaultValue:DataTypes.NOW,
    get(){
      const val = this.getDataValue('create_time')
      return dayjs(val).format("YYYY-MM-DD HH:mm:ss")
    }
  }
})
// 建立关联关系
MenuRoleModel.associations = function(){
  MenuModel.belongsToMany(RoleModel,{
    through:MenuRoleModel,
    foreignKey:'menu_id',
    otherKey:'role_id'
  })

  RoleModel.belongsToMany(MenuModel,{
    through:MenuRoleModel,
    foreignKey:'role_id',
    otherKey:'menu_id'
  })
}

module.exports = MenuRoleModel