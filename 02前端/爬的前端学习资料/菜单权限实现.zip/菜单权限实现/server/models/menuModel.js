const { DataTypes } = require('sequelize')
const dayjs = require('dayjs')
const sequelize = require('../utils/db')

const MenuModel = sequelize.define('menu',{
  id:{
    type:DataTypes.INTEGER.UNSIGNED,
    autoIncrement:true,
    primaryKey:true
  },
  name:{
    type:DataTypes.STRING
  },
  parent_id:{
    type:DataTypes.MEDIUMINT,
    defaultValue:0
  },
  link_url:{
    type:DataTypes.STRING
  },
  component:{
    type:DataTypes.STRING
  },
  create_time:{
    type:DataTypes.DATE,
    defaultValue:DataTypes.NOW,
    get(){
      const val = this.getDataValue('create_time')
      return dayjs(val).format("YYYY-MM-DD HH:mm:ss")
    }
  }
})

module.exports = MenuModel