const Koa = require('koa')
const bodyParser = require('koa-bodyparser')
const cors = require('koa2-cors')
const userRouter = require('./routers/admin/user')
const roleRouter = require('./routers/admin/role')
const menuRouter = require('./routers/admin/menu')
const verifyAuth = require('./middlewares/auth')
const catcheError = require('./middlewares/catchError')

const app = new Koa()
app.signScrect = {
  screctKey:'wsx85dwang65',
  expiresIn:'24h'
}

app.use(bodyParser())
app.use(cors())
app.use(verifyAuth)
app.use(catcheError)


/** 路由中间件 */
app.use(userRouter.routes())
app.use(roleRouter.routes())
app.use(menuRouter.routes())


app.listen(3000,()=>{
  console.log('server is running')
})