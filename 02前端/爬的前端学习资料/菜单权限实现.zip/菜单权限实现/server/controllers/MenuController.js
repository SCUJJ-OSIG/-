const { Op } = require('sequelize')
const MenuModel = require('../models/menuModel')
const RoleModel = require('../models/roleModel')
const MenuRoleModel = require('../models/roleMenuModel')
const { listToJson, listToTree } = require('../utils/helper')

MenuRoleModel.associations()

// MenuRoleModel.sync()
const MenuCreate = async (ctx,next) => {
  const { name, parent_id, link_url, component } = ctx.request.body
  const menu = await MenuModel.create({ name, parent_id, link_url, component })
  
  ctx.body = {
    code:200,
    msg:'create menu',
    data:menu
  }
  await next()
}

const MenuList = async (ctx,next) => {
  const result = await MenuModel.findAll()
  const arrList = listToJson(result);

  const dataList = listToTree('id','parent_id',arrList);
  ctx.body = {
    code:200,
    msg:'create list',
    data:dataList
  }
  await next()
}

// 给角色添加菜单
const addRoleMenu = async (ctx,next) => {
  const { r_id, menu_id } = ctx.request.body

  const destoryRes = await MenuRoleModel.destroy({
    where: {
      role_id: {
        [Op.eq]: r_id
      }
    }
  })


  const menu_ids = menu_id.split(',').map(item => {
    return {
      menu_id:Number(item),
      role_id:r_id
    }
  })

  console.log(menu_ids)
  
  const result = await MenuRoleModel.bulkCreate(menu_ids)

  ctx.body = {
    code:200,
    msg:'add role menu',
    data:result
  }
  await next()
}

const getRoleMenu = async (ctx,next) => {
  const {r_id} = ctx.query
  const res = await RoleModel.findOne({
    where:{
      id:r_id
    },
    include:{
      model:MenuModel
    }
  })
  ctx.body = {
    code:200,
    msg:'role menu',
    data:res
  }
  await next()
}

const menuTree = async (ctx,next) => {
  const r_id = ctx.auth.scope
  const res = await RoleModel.findOne({
    where:{
      id:r_id
    },
    include:{
      model:MenuModel
    }
  })

  if(!res){
    ctx.body = {
      code:200,
      msg:'role menu',
      data:{
        menus:[]
      }
    }
    return
  }

  // const arrList = listToJson(res.menus);

  // const dataList = listToTree('id','parent_id',arrList);
  ctx.body = {
    code:200,
    msg:'role menu',
    data:res
  }
  await next()
}

module.exports = {
  MenuCreate,
  MenuList,
  getRoleMenu,
  addRoleMenu,
  menuTree
}