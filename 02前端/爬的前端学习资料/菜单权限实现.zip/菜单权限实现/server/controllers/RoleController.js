
const RoleModel = require('../models/roleModel')
// RoleModel.sync()

const RoleCreate = async (ctx,next) => {
  const { name } = ctx.request.body

  const role = await RoleModel.create({ name })

  ctx.body = {
    msg:'admin role create',
    code:200,
    data:role
  }
  await next()
}

const RoleList = async (ctx,next) => {
  const list = await RoleModel.findAll({
    where:{
      status:1
    }
  })
  ctx.body = {
    msg:'list role',
    code:200,
    data:list
  }
  await next()
}

module.exports = {
  RoleCreate,
  RoleList
}