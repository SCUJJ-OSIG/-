const jwt = require('jsonwebtoken')
const md5 = require('md5')
const AdminUserModel = require('../models/accountModel')
const RoleModel = require('../models/roleModel')
// AdminUserModel.sync()

RoleModel.hasMany(AdminUserModel,{ foreignKey:'r_id', sourceKey:'id' })
AdminUserModel.belongsTo(RoleModel,{ foreignKey:'r_id', targetKey:'id' })

console.log(md5('abc12345'))

/**
 * 创建管理端账户
 * @param phone : 账户账号
 * @param password : 账户密码
 * @param name : 账户昵称
 * @param r_id : 角色id 选填 默认为 0 
 */
const AdminUserCreate = async (ctx,next) => {
  if(ctx.auth.scope !== 1){
    ctx.body = {
      code:200103,
      msg:'无添加菜单权限'
    }
    await next()
    return
  }
  const {phone,password,name,r_id} = ctx.request.body
  const user = await AdminUserModel.create({phone,password,name,r_id})
  ctx.body = {
    msg:'admin user create',
    code:200,
    data:user
  }
  await next()
}

const AdminUserUpdate = async (ctx,next) => {
  const { r_id, id } = ctx.request.body 
  const result = await AdminUserModel.update({ r_id },{
    where:{
      id
    }
  })
  ctx.body = {
    code:200,
    data:result
  }
}
/**
 * 账户列表
 * @param {*} pageNum 当前页
 * @param {*} pageSize 每页数量
 * @returns 
 */
const AdminUserList = async (ctx,next) => {
  const { pageNum, pageSize } = ctx.query
  const offset = pageNum ? Number(pageNum) - 1 : 0
  const limit = pageSize ? Number(pageSize) : 10
  if(offset < 0 || limit < 1){
    ctx.body = {
      msg:'parameter error'
    }
    return
  }
  const data = await AdminUserModel.findAndCountAll({
    offset:offset*limit,
    limit,
    order:[
      ['create_time','DESC']
    ],
    include:{
      model:RoleModel
    },
    attributes:{
      exclude:['password']
    }
  })
  ctx.body = {
    msg:'admin user list',
    code:200,
    data
  }
}

const AdminLogin = async (ctx,next) => {
  const { phone, password } = ctx.request.body

  const user = await AdminUserModel.verifyAccountPassword(phone, password)
  const { screctKey, expiresIn } = ctx.app.signScrect
  const token = jwt.sign({
    uid:user.id,
    scope:user.r_id
  },screctKey,{ expiresIn })

  ctx.body = {
    data:{
      phone:user.phone,
      name:user.name,
      status:user.status,
      r_id:user.r_id,
      id:user.id,
      token
    },
    msg:'success',
    code:200
  }
}

module.exports = {
  AdminUserCreate,
  AdminUserList,
  AdminLogin,
  AdminUserUpdate
}