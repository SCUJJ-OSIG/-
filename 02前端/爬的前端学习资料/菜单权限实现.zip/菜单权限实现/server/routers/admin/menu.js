const Router = require('@koa/router')
const {
  MenuCreate,
  MenuList,
  addRoleMenu,
  getRoleMenu,
  menuTree
} = require('../../controllers/MenuController')
const menuRouter = new Router({
  prefix:'/admin'
})

// 创建账户 路由
menuRouter.post('/menuCreate',MenuCreate)
menuRouter.get('/menuList',MenuList)

menuRouter.post('/addRoleMenu',addRoleMenu)

menuRouter.get('/menuchecked',getRoleMenu)

menuRouter.get('/menu',menuTree)


module.exports = menuRouter