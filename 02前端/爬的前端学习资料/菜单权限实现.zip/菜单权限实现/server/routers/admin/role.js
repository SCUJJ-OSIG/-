const Router = require('@koa/router')
const {
  RoleCreate,
  RoleList
} = require('../../controllers/RoleController')
const roleRouter = new Router({
  prefix:'/admin'
})

// 创建账户 路由
roleRouter.post('/roleCreate',RoleCreate)

// 账户列表分页查询
roleRouter.get('/roleList',RoleList)

module.exports = roleRouter