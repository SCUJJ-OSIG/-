const Router = require('@koa/router')
const {
  AdminUserCreate,
  AdminUserList,
  AdminLogin,
  AdminUserUpdate
} = require('../../controllers/AdminUser')
const userRouter = new Router({
  prefix:'/admin'
})

// 创建账户 路由
userRouter.post('/userCreate',AdminUserCreate)

// 账户列表分页查询
userRouter.get('/userListByPage',AdminUserList)

userRouter.post('/userUpdate',AdminUserUpdate)

// 管理后台登录
userRouter.post('/login',AdminLogin)

module.exports = userRouter