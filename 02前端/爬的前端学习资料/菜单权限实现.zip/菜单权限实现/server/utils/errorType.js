
class ParameterError extends Error{
  constructor(msg){
    super()
    this.msg = msg || '参数错误'
    this.code = 200102
  }
}

class NotExist extends Error{
  constructor(msg){
    super()
    this.msg = msg || '不存在',
    this.code = 200101
  }
}

module.exports = {
  ParameterError,
  NotExist
}