const listToJson = (oldArr) => {
  return oldArr.map(item => item.toJSON());
}

const listToTree = (mid,pid,list) => {
  function exists(list,parentId){
      for(var i=0;i<list.length;i++){
          if(list[i][mid] == parentId) return true;
      }
      return false
  }

  var nodes = [];
  for(var i=0;i<list.length;i++){
      var raw = list[i];
      if(!exists(list,raw[pid])){
          nodes.push(raw)
      }
  }

  for(var i=0;i<nodes.length;i++){
      nodes[i].children = [];
      for(var j=0;j<list.length;j++){
          if(nodes[i][mid]==list[j][pid]){
              nodes[i].children.push(list[j])
          }
      }
  }
  return nodes;
}

module.exports = {
  listToJson,
  listToTree
}