const { Sequelize } = require('sequelize')

const sequelize = new Sequelize({
  database:'some',
  username:'root',
  password:'abc12345',
  host:'localhost',
  port:3306,
  dialect:'mysql',
  timezone:'+08:00',
  define:{
    timestamps:true,
    freezeTableName:true,
    createdAt:'create_time',
    updatedAt:false
  }
})

module.exports = sequelize