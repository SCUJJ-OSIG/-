const jwt = require('jsonwebtoken')
const notVerifies = ['/admin/login']
const verifyAuth = async (ctx,next) => {
  const path = ctx.path
  if(notVerifies.includes(path)){
    await next()
    return
  }
  
  const { token } = ctx.req.headers
  if(!token){
    ctx.body = {
      code:403,
      msg:'no login'
    }
    return
  }

  const t = token.replace(/Bearer /,'')
  const { screctKey } = ctx.app.signScrect
  
  try {
    const jwtObj = jwt.verify(t,screctKey)
    ctx.auth = {
      udd:jwtObj.uid,
      scope:jwtObj.scope
    }
    await next()
  } catch (error) {
    if(error.name === 'TokenExpiredError'){
      ctx.body = {
        msg:'jwt expired'
      }
    }
  }
}

module.exports = verifyAuth