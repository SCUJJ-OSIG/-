const canvas = document.querySelector('.canvas')
const cxt = canvas.getContext('2d')

canvas.width = window.innerWidth
canvas.height = window.innerHeight

// 定义一个存储已绘制图形的数组
const shapeList = []
// 定义一个变量 标识 鼠标是否按下 默认为false
let isDown = false
// 定义一个变量保存 第一次鼠标按下的 点坐标
const firstPoint = {x:0, y:0}
// 鼠标最后一次移动时的 x y w h信息
const lastMove = {x:0, y:0, w:0, h:0}

let activeShape = null

function animate(){
    window.requestAnimationFrame(animate)
    cxt.clearRect(0,0,canvas.width,canvas.height)
    shapeList.forEach(shape => {
        shape.draw(cxt)
    })
    if(activeShape){
        shapeList.forEach(shape => {
            shape.isAnchor = false
        })
        activeShape.isAnchor = true
    }
}
animate()

const shapeMap = {
    rect:{
        create:() => {
            activeShape = new Rectangle({
                rectInfo:{
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                },
                style:{ 
                    zIndex:1, 
                    strokeColor:strokeColor, 
                    fillColor:fillColor,
                    corner:cornerRadius,
                    border:borderStyle
                }
            })
        },
        move:({x, y, width, height}) => {
            activeShape.rectInfo = { x, y, width, height}
        }
    },
    ellipse:{
        create:() => {
            activeShape = new Ellipse({
                rectInfo:{
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                },
                style:{ 
                    zIndex:1, 
                    strokeColor:strokeColor, 
                    fillColor:fillColor,
                    corner:cornerRadius,
                    border:borderStyle
                }
            })
        },
        move:({x, y, width, height}) => {
            activeShape.rectInfo = { x, y, width, height}
        }
    }
}

// 绑定mousedown事件
canvas.addEventListener('mousedown',event => {
    // 鼠标按下 立即 获取到当前点的坐标值
    const { offsetX, offsetY } = event
    firstPoint.x = offsetX
    firstPoint.y = offsetY
    isDown = true

    // 点击下去，把点中的图形放到pointList集合中
    let pointList = []
    shapeList.forEach(shape => {
        const isContain = shape.isPointInPath(offsetX, offsetY)
        isContain && pointList.push(shape)
    })
    // 如果没有点中任何一个图形，那么所有图形置为空
    if(!pointList.length && activeShape) {
        activeShape.isAnchor = false
        activeShape = null
    }

    if(shapeMap[actionType]){
        shapeMap[actionType].create()
        shapeList.push(activeShape)
    }
    
    if(actionType === 'select'){
        if(pointList.length){
            // 要先对pointList进行排序，zIndex大的 排在前面
            pointList.sort((a,b) => b.style.zIndex - a.style.zIndex)
            activeShape = pointList[0]
            // 用Math.max()方法找到所有图形中zIndex最大的值
            activeShape.style.zIndex = Math.max(...shapeList.map(shape => shape.style.zIndex)) + 1
            // 重新排序，zindex越小，层级越低，数组中越靠前，越早渲染。后渲染的就在先渲染的上面。
            // sort方法，从低到高排序，参数1 减 参数2
            shapeList.sort((a,b) => a.style.zIndex - b.style.zIndex)
            activeShape.pointOffset(offsetX, offsetY)
        }
    }
})

canvas.addEventListener('mousemove',event => {
    // 移动的时候实时获取到点的坐标值
    const { offsetX, offsetY } = event
    if(isDown){
        const x = offsetX > firstPoint.x ? firstPoint.x : offsetX
        const y = offsetY > firstPoint.y ? firstPoint.y : offsetY
        const w = Math.abs(offsetX - firstPoint.x)
        const h = Math.abs(offsetY- firstPoint.y)

        if(activeShape && shapeMap[actionType]){
            shapeMap[actionType].move({ x, y, width:w, height:h })
        }
        if(activeShape && actionType === 'select'){
            const { offsetX:x, offsetY:y } = event
            activeShape.setPosition(x,y)
        }
    }
})

document.addEventListener('mouseup',() => {
    isDown = false
    lastMove.w = 0
    lastMove.h = 0
})