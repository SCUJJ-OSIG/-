const toolContainer = document.querySelector('.toolbar-container')
const tools = document.querySelectorAll('.tool')
// 把tools 集合转换成数组
const toolsArr = Array.prototype.slice.call(tools)

let actionType = 'create'
const toolMap = {
    select:'select',
    rect:'rect',
    rhombus:'rhombus',
    ellipse:'ellipse'
}

toolContainer.addEventListener('click', (event) => {
    const curr = event.target.dataset.tool
    toolsArr.forEach(tool => {
        // 循环数组把每个tool元素 移除class类 active
        tool.classList.remove('active')
        // 并给点击的那个 tool 加上active
        if(tool.dataset.tool === curr){
            tool.classList.add('active')
            actionType = toolMap[curr]
        }
    })
})

window.addEventListener('keypress', (event) => {
    console.log(event)
    switch(event.code){
        case 'Digit1':
            actionType = 'select'
            break;
        case 'Digit2':
            actionType = 'rect'
            break;
        case 'Digit3':
            actionType = 'ellipse'
            break;
    }
    toolsArr.forEach(tool => {
        // 循环数组把每个tool元素 移除class类 active
        tool.classList.remove('active')
        // 并给点击的那个 tool 加上active
        if(tool.dataset.tool === actionType){
            tool.classList.add('active')
        }
    })
})

const colorBtn = document.querySelector('.color')
const colors = Array.prototype.slice.call(colorBtn.children)
const backgroundBtn = document.querySelector('.background')
const backgrounds = Array.prototype.slice.call(backgroundBtn.children)

let strokeColor = '#1e1e1e'
colorBtn.addEventListener('click',(event) => {
    const currColor = event.target.dataset.color
    strokeColor = currColor
    console.log(activeShape,'==')
    if(activeShape){
        activeShape.style.strokeColor = currColor
    }
    colors.forEach(color => {
        // 循环数组把每个color元素 移除class类 active
        color.classList.remove('active')
        // 并给点击的那个 color 加上active
        if(color.dataset.color === currColor){
            color.classList.add('active')
        }
    })
})

let fillColor = '#a5d8ff'
backgroundBtn.addEventListener('click',(event) => {
    const currColor = event.target.dataset.color
    fillColor = currColor
    if(activeShape){
        activeShape.style.fillColor = currColor
    }
    backgrounds.forEach(color => {
        // 循环数组把每个color元素 移除class类 active
        color.classList.remove('active')
        // 并给点击的那个 color 加上active
        if(color.dataset.color === currColor){
            color.classList.add('active')
        }
    })
})

let cornerRadius = 'butt'
const cornerBtn = document.querySelector('.corner-style')
const corners = Array.prototype.slice.call(cornerBtn.children)
cornerBtn.addEventListener('click', (event) => {
    const currCorner = event.target.dataset.corner
    corners.forEach(corner => {
        // 循环数组把每个corner元素 移除class类 active
        corner.classList.remove('active')
        // 并给点击的那个 corner 加上active
        if(corner.dataset.corner === currCorner){
            corner.classList.add('active')
        }
    })
    cornerRadius = currCorner
    if(activeShape){
        activeShape.style.corner = cornerRadius
    }
})

let borderStyle = 'solid'
const borderBtn = document.querySelector('.border-style')
const borders = Array.prototype.slice.call(borderBtn.children)
borderBtn.addEventListener('click', (event) => {
    const currBorder = event.target.dataset.border
    console.log(event.target)
    borders.forEach(border => {
        // 循环数组把每个border元素 移除class类 active
        border.classList.remove('active')
        // 并给点击的那个 border 加上active
        if(border.dataset.border === currBorder){
            border.classList.add('active')
        }
    })
    borderStyle = currBorder
    if(activeShape){
        activeShape.style.border = borderStyle
    }
})