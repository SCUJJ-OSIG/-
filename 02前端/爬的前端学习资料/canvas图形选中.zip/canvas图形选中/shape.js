class ShapeBase {
    constructor({ rectInfo, style }){
        this.rectInfo = rectInfo
        this.offsetX = this.offsetY = 0
        this.style = Object.assign({},{
            fillColor:'#a5d8ff',
            strokeColor:'#1e1e1e',
            corner:'butt',
            border:'solid',
            zIndex:0
        },style)
        this.isAnchor = false
    }
    pointOffset(pointX,pointY){
        const { x, y } = this.rectInfo
        // 点击的位置 减去 矩形原始的位置，得出 鼠标在矩形内的偏移量
        this.offsetX = pointX - x
        this.offsetY = pointY - y
    }
    // 判断当前点击的位置是否在图形上
    isPointInPath(pointX, pointY){
        const { x, y, width, height } = this.rectInfo
        return (
            pointX > x && pointX < x + width &&
            pointY > y && pointY < y + height
        )
    }
    // 重新设置图形的位置
    setPosition(posX, posY){
        const { offsetX, offsetY } = this
        this.rectInfo.x = posX - offsetX
        this.rectInfo.y = posY - offsetY
    }
    // 绘制锚点
    drawArc(anchors){
        cxt.lineWidth = 1
        cxt.strokeStyle = 'red'
        cxt.fillStyle = '#ffffff'
        for(let i=0;i<anchors.length;i++){
            cxt.beginPath()
            cxt.arc(anchors[i].x,anchors[i].y,anchors[i].radius,0,Math.PI*2)
            cxt.fill()
            cxt.stroke()
        } 
    }
    // 绘制虚线边框
    drawDashBorder({ x, y, width, height }){
        if(this.isAnchor && width > 0 && height > 0){
            cxt.beginPath()
            cxt.setLineDash([2,2])
            cxt.lineWidth = 1
            cxt.strokeStyle = 'red'
            cxt.rect(x-5,y-5,width+10,height+10)
            cxt.stroke()
            cxt.closePath()
            
            const anchors = [
                {x:x-5, y:y-5, radius:5},
                {x:(x-5 + (width+10)/2), y:y-5, radius:5},
                {x:(x-5 + (width+10)), y:y-5, radius:5},
                {x:x-5, y:(y-5 + (height+10)/2), radius:5},
                {x:(x-5 + (width+10)), y:(y-5 + (height+10)/2), radius:5},
                {x:x-5, y:(y-5 + (height+10)), radius:5},
                {x:(x-5 + (width+10)/2), y:(y-5 + (height+10)), radius:5},
                {x:(x-5 + (width+10)), y:(y-5 + (height+10)), radius:5}
            ]
            this.drawArc(anchors)
            cxt.restore()
        }
    }
    // 设置样式
    setStyle(cxt){
        const { fillColor, strokeColor } = this.style
        if(this.style.border === 'solid'){
            cxt.setLineDash([])
        }
        if(this.style.border === 'dash1'){
            cxt.setLineDash([6,2])
        }
        if(this.style.border === 'dash2'){
            cxt.setLineDash([2,2])
        }
        cxt.lineWidth = 2
        cxt.fillStyle = fillColor
        cxt.strokeStyle = strokeColor
    }
}

// 矩形类
class Rectangle extends ShapeBase{
    constructor({ rectInfo, style }){
        super({ rectInfo, style })
        this.radius = 10
    }
    draw(cxt){
        const { x, y, width, height } = this.rectInfo
        
        cxt.beginPath()
        cxt.save()
        this.setStyle(cxt)
        if(this.style.corner === 'round'){
            this.drawCorner({ x, y, width, height, radius:this.radius })
        }
        if(this.style.corner === 'butt'){
            cxt.rect(x, y, width, height)
        }
        cxt.closePath()
        cxt.fill()
        cxt.stroke()
        
        this.drawDashBorder({ x, y, width, height })
    }
    drawCorner({x,y,width,height,radius}){
        // 左上圆角
        cxt.arc(x+radius,y+radius,radius,Math.PI,Math.PI*1.5,false)
        // 上边线条
        cxt.lineTo(x+radius,y)
        cxt.lineTo(x+width-radius,y)
        //右上圆角
        cxt.arc(x+width-radius,y+radius,radius,Math.PI*1.5,0)
        // 右边线条
        cxt.lineTo(x+width,y+radius)
        cxt.lineTo(x+width,y+height-radius)
        // 右下圆角
        cxt.arc(x+width-radius,y+height-radius,radius,0,Math.PI*0.5)
        // 下边线条
        cxt.lineTo(x+width-radius,y+height)
        cxt.lineTo(x+radius,y+height)
        // 坐下圆角
        cxt.arc(x+radius,y+height-radius,radius,Math.PI*0.5,Math.PI)
        // 左边线条
        cxt.lineTo(x,y+height-radius)
        cxt.lineTo(x,y+radius)
    }
}

// 椭圆类
class Ellipse extends ShapeBase{
    constructor({ rectInfo, style }){
        super({ rectInfo, style })
    }
    draw(cxt){
        const { x, y, width, height } = this.rectInfo
        cxt.beginPath()
        cxt.save()
        this.setStyle(cxt)
        // 椭圆的中心点 各自在x y轴基础上加 矩形宽高的一半
        const center = {
            x: x + width/2,
            y: y + height/ 2
        }
        cxt.ellipse(center.x,center.y,width / 2,height / 2, 0, 0, Math.PI*2)
        cxt.closePath()
        cxt.fill()
        cxt.stroke()
        
        this.drawDashBorder({ x, y, width, height })
    }
}