
export default (cvs,callback) => {
      const ctx = cvs.getContext('2d')
      let rectInfo = {
          startx: 30,
          starty: 16,
          width: 215,
          height: 215,
          endx: 245,
          endy: 231
      }
      callback(rectInfo)
      let anchorArrs = []
      
      function fillBlack() {
          ctx.beginPath()
          ctx.save()
          ctx.fillStyle = 'rgba(0,0,0,0.4)'
          ctx.lineWidth = 2
          ctx.fillRect(0, 0, cvs.width, cvs.height)
      }
      fillBlack()
      
      
      function drawRect() {
          const { startx, starty, width, height } = rectInfo
          ctx.clearRect(startx, starty, width, height)
          ctx.restore()
          ctx.beginPath()
          ctx.lineWidth = 2
          ctx.strokeStyle = '#fff'
          ctx.strokeRect(startx, starty, width, height)
      }
      drawRect()
      
      
      function anchors() {
          const { startx, starty, width, height } = rectInfo
          const r = 5
          anchorArrs = [
              { x: startx, y: starty, cursor: 'nwse-resize' },
              { x: startx + width, y: starty, cursor: 'nesw-resize' },
              { x: startx + width, y: starty + height, cursor: 'nwse-resize' },
              { x: startx, y: starty + height, cursor: 'nesw-resize' }
          ]
          anchorArrs.forEach(item => {
              ctx.beginPath()
              ctx.strokeStyle = '#fff'
              ctx.fillStyle = '#000'
              ctx.arc(item.x, item.y, r, 0, 2 * Math.PI, false)
              ctx.fill()
              ctx.stroke()
          })
      }
      anchors()
      let isDown = false
      let selectAnchorIndex
      let action = 'auto'
      let downPoint = {}
      cvs.addEventListener('mousedown', e => {
          isDown = true
          const { offsetX, offsetY } = e
          const { startx, starty, width, height, endx, endy } = rectInfo
          downPoint = { stx: offsetX, sty: offsetY }
          if (selectAnchorIndex !== -1) {
              action = 'resize'
              downPoint.rawrect = { startx, starty, width, height, endx, endy }
              return
          }
          if (offsetX > startx && offsetX < endx && offsetY > starty && offsetY < endy) {
              action = 'move'
              downPoint.offsetx = offsetX - startx
              downPoint.offsety = offsetY - starty
          } else {
              action = 'auto'
          }
      })
      cvs.addEventListener('mousemove', e => {
          if (isDown) {
              handleDrag(e)
              return
          }
          const { offsetX, offsetY } = e
          const { startx, starty, endx, endy } = rectInfo
          let selectAnchor, selectIndex = -1
          anchorArrs.forEach((item, i) => {
              const { x, y } = item
              if (Math.abs(offsetX - x) <= 10 && Math.abs(offsetY - y) <= 10) {
                  selectAnchor = item
                  selectIndex = i
              }
          })
          selectAnchorIndex = selectIndex
          if (selectAnchor) {
              document.body.style.cursor = selectAnchor.cursor
              return
          }
      
          if (offsetX > startx && offsetX < endx && offsetY > starty && offsetY < endy) {
              document.body.style.cursor = 'move'
          } else {
              document.body.style.cursor = 'auto'
          }
      
      })
      document.documentElement.addEventListener('mouseup', () => {
          isDown = false
          callback(rectInfo)
      })
      function handleDrag(e) {
          const { offsetX, offsetY } = e
          const { stx, sty, offsetx, offsety } = downPoint
          let { startx, starty, width, height, endx, endy } = rectInfo
          if (action === 'move') {
              ctx.clearRect(0, 0, cvs.width, cvs.height)
              const newx = offsetX - offsetx
              const newy = offsetY - offsety
              
              rectInfo.startx = newx
              if(rectInfo.startx < 0){
                rectInfo.startx = 0
              }
              if(rectInfo.startx > cvs.width - width){
                rectInfo.startx = cvs.width - width
              }
              
              rectInfo.starty = newy
              if(rectInfo.starty < 0){
                rectInfo.starty = 0
              }
              if(rectInfo.starty > cvs.height - height){
                rectInfo.starty = cvs.height - height
              }
              rectInfo.endx = newx + width
              rectInfo.endy = newy + height
              fillBlack()
              drawRect()
              anchors()
          }
          if (action === 'resize') {
              ctx.clearRect(0, 0, cvs.width, cvs.height)
              const rawrect = downPoint.rawrect
              let newWidth = rawrect.width,
                  newHeight = rawrect.height,
                  newStartx = rawrect.startx,
                  newStarty = rawrect.starty,
                  newEndx = rawrect.endx,
                  newEndy = rawrect.endy
              if (selectAnchorIndex === 0) {
                  newWidth = rawrect.width - (offsetX - stx)
                  newHeight = rawrect.height - (offsetY - sty)
                  newStartx = rawrect.startx + (offsetX - stx)
                  newStarty = rawrect.starty + (offsetY - sty)
              }
              if (selectAnchorIndex === 1) {
                  newWidth = rawrect.width + offsetX - stx
      
                  newHeight = rawrect.height - (offsetY - sty)
                  newStarty = rawrect.starty + (offsetY - sty)
              }
              if (selectAnchorIndex === 2) {
                  newWidth = rawrect.width + offsetX - stx
                  newHeight = rawrect.height + offsetY - sty
                  newEndx = rawrect.endx + offsetX - stx
                  newEndy = rawrect.endy + offsetY - sty
              }
              if (selectAnchorIndex === 3) {
                  newWidth = rawrect.width - (offsetX - stx)
                  newHeight = rawrect.height + (offsetY - sty)
                  newStartx = rawrect.startx + (offsetX - stx)
              }
      
      
              rectInfo.width = newWidth
              rectInfo.height = newHeight
              rectInfo.startx = newStartx
              rectInfo.starty = newStarty
              rectInfo.endx = newEndx
              rectInfo.endy = newEndy
              fillBlack()
              drawRect()
              anchors()
          }
      }
    }